export const depositSearchableField = ["phoneNumber", "paymentMethod"];

export const depositFilterableField = ["searchTerm", "phoneNumber"];
