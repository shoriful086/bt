export const userSearchableField = ["email", "phoneNumber"];

export const userFilterableField = ["searchTerm", "phoneNumber", "email"];
