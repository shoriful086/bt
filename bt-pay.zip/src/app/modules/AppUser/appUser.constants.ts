export const userSearchableField = ["email", "phoneNumber"];

export const userFilterableField = [
  "searchTerm",
  "email",
  "phoneNumber",
  "referrelCode",
];
