export type IMethodData = {
  paymentReceivedNumber: string;
  paymentMethod: string;
  amount: number;
};
