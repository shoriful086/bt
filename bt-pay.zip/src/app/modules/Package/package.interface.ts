export type IPackage = {
  name: string;
  price: number;
  dailyAds: number;
  validity: string;
};
