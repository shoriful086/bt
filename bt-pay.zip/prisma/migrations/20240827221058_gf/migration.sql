-- AlterTable
ALTER TABLE "appUsers" ALTER COLUMN "depositBalance" SET DEFAULT '0',
ALTER COLUMN "depositBalance" SET DATA TYPE TEXT;
