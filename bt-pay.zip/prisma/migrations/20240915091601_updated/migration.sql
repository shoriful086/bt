-- AlterTable
ALTER TABLE "appUsers" ADD COLUMN     "oneSignalUserId" TEXT;
