-- AlterTable
ALTER TABLE "deposits" ALTER COLUMN "amount" DROP DEFAULT;
