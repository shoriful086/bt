-- CreateTable
CREATE TABLE "banners" (
    "id" TEXT NOT NULL,
    "bannerImage" TEXT NOT NULL,

    CONSTRAINT "banners_pkey" PRIMARY KEY ("id")
);
