-- AlterTable
ALTER TABLE "appUsers" ALTER COLUMN "balance" SET DEFAULT 0,
ALTER COLUMN "depositBalance" SET DEFAULT 0;
