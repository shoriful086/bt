-- AlterTable
ALTER TABLE "appUsers" ADD COLUMN     "isDeleted" BOOLEAN NOT NULL DEFAULT false;
