-- AlterTable
ALTER TABLE "Package" ALTER COLUMN "validity" SET DATA TYPE TEXT;
