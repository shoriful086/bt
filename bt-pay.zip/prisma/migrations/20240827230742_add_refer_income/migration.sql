-- AlterTable
ALTER TABLE "appUsers" ADD COLUMN     "referIncome" TEXT NOT NULL DEFAULT '0';
