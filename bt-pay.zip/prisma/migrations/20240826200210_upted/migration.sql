-- CreateTable
CREATE TABLE "SignUpBonus" (
    "id" TEXT NOT NULL,
    "bonusAmount" TEXT NOT NULL,

    CONSTRAINT "SignUpBonus_pkey" PRIMARY KEY ("id")
);
